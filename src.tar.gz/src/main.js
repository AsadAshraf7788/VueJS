import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')



// In order to inject attributes in HTML tags
new Vue({
   el : '#app-one',
   data : {
     title : 'Hello World'
   },
   methods:{
    changeMethod(){
      this.title = "TitleBYMethod"
    }
   }
});

// counter clicker!

new Vue({
  el : "#click-app",
  data : {
    numberOfClicks : 0,
    Counter : 0
  },
  methods : {
    clickMethod(){
      this.numberOfClicks = this.numberOfClicks+ 1
    }
  },
  computed : {
    counter(){
      return this.numberOfClicks * 2
    }
  }
})

// Conditionals

new Vue({
  el : "#conditionals",
  data :{
    show : true
  },
  methods :{

  }
})


// Looops
new Vue(
  {
    el : "#loop",
    data : {
      Person : [
        {name : 'Asad', Degree: "BS(CS)", University: "FAST"},
        {name : "Usama ", Degree:  "CHamical Eng.", University: "UET"},
        {name : "Ahbar", Degree: "Mining Eng.", University: "UET"}
      ]
    },

    methods :{

    }
  }
)
// Filters

new Vue({
  el : "#filters",
  data : {
    Person : [
      {name : 'Asad', Degree: "BS(CS)", University: "FAST"},
      {name : "Usama ", Degree:  "CHamical Eng.", University: "UET"},
      {name : "Ahbar", Degree: "Mining Eng.", University : "UET"}]
  },
  filters : {
    uppercase : function(value){
      return value.toUppercase();
    }
  }
})

// Components


Vue.component('app-user', {
  data: function(){
    return {
      Person : [{name : 'Asad', Degree: "BS(CS)", University: "FAST"},
      {name : "Usama ", Degree:  "CHamical Eng.", University: "UET"},
      {name : "Ahbar", Degree: "Mining Eng.", University : "UET"}]
    }
  },

  template : `<div class="user">
  <li v-for="(Person) in Person">
      {{ Person.name }} - 
      {{Person.University}} - 
      {{Person.Degree}}
  </li>
<hr>
</div>  `
})
new Vue({
  el : "#component",
  data :{
   
  },
  methods:{
    
  }
})